with open('/Users/sarahwashington/Desktop/carousel/treasure1','w') as f_open:
   data = f_open.write('\033[38;5;135m▃]'),
   data = f_open.write('\033[48;5;135m▃]'),
   data = f_open.write('\033[48;5;136m▃▃▃]'),
   data = f_open.write('\033[38;5;139m▃▃▃]')
   data = f_open.write('\033[38;5;135m▃▃▃]')